from setuptools import setup, find_packages

setup(
    name='sinotrans',
    version='0.2.8',
    author='Qyt',
    author_email='674805186@qq.com',
    description='工具类-ai模型超时检测&心跳机制&指数退避重试',
    packages=find_packages(),
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)