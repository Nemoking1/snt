from setuptools import setup, find_packages

setup(
    name='sinotrans',
    version='0.2.9',
    author='Qyt',
    author_email='674805186@qq.com',
    description='工具类-Rule新增considerEmpty',
    packages=find_packages(),
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)